
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class Calculate_revenue extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtDay;
	private JTextField txtYear;
	private JTextField txtMonth;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculate_revenue frame = new Calculate_revenue();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculate_revenue() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 389, 195);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRevenue = new JLabel("Revenue");
		lblRevenue.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblRevenue.setBounds(153, 4, 80, 25);
		contentPane.add(lblRevenue);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.DARK_GRAY);
		separator.setBounds(6, 34, 377, 12);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.DARK_GRAY);
		separator_1.setBounds(6, 128, 377, 12);
		contentPane.add(separator_1);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Admin_menu admin = new Admin_menu();
				admin.setVisible(true);
			}
		});
		btnBack.setBounds(320, 141, 63, 29);
		contentPane.add(btnBack);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(320, 6, 63, 29);
		contentPane.add(btnExit);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtDay.setText("01");
				txtMonth.setText("01");
				txtYear.setText("2000");

			}
		});
		btnReset.setBounds(238, 53, 63, 29);
		contentPane.add(btnReset);
		
		JLabel lblDay = new JLabel("Day");
		lblDay.setBounds(142, 58, 33, 16);
		contentPane.add(lblDay);
		
		txtDay = new JTextField();
		txtDay.setText("01");
		txtDay.setBounds(139, 86, 33, 26);
		contentPane.add(txtDay);
		txtDay.setColumns(10);
		
		JLabel lblYear = new JLabel("Year");
		lblYear.setBounds(45, 58, 39, 16);
		contentPane.add(lblYear);
		
		txtYear = new JTextField();
		txtYear.setText("2000");
		txtYear.setBounds(35, 86, 49, 26);
		contentPane.add(txtYear);
		txtYear.setColumns(10);
		
		JLabel lblMonth = new JLabel("Month");
		lblMonth.setBounds(88, 58, 49, 16);
		contentPane.add(lblMonth);
		
		txtMonth = new JTextField();
		txtMonth.setText("01");
		txtMonth.setBounds(94, 86, 33, 26);
		contentPane.add(txtMonth);
		txtMonth.setColumns(10);
		
		JLabel label = new JLabel("-");
		label.setBounds(86, 91, 8, 16);
		contentPane.add(label);

		JLabel label_1 = new JLabel("-");
		label_1.setBounds(129, 91, 8, 16);
		contentPane.add(label_1);
		
		JButton btnCalculate = new JButton("Calculate");
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int rev=0;
				int re=0;
				int p=1;
				String day1 = "";
				String year = txtYear.getText();
				String month = txtMonth.getText();
				String day = txtDay.getText();
				if(day.trim().equals("")) {
					day1="1";
				}
				else
				{
					day1=day;				
				}
				while(p==1) {
					p++;
				
				if("".equals(year.trim()) || "".equals(month.trim())){
					JOptionPane.showMessageDialog(null,"Select at least the month and year","Error",JOptionPane.ERROR_MESSAGE);
					break;
					
				}
		        if((Integer.parseInt(year)>=1900 && Integer.parseInt(year) <= 2100)&&((Integer.parseInt(month)>=10 && Integer.parseInt(month)<=12)
		        		||"01".equals(month)||"02".equals(month)||"03".equals(month)
		        		||"04".equals(month)||"05".equals(month)||"06".equals(month)
		        		||"07".equals(month)||"08".equals(month)||"09".equals(month))&&(((Integer.parseInt(day1)>=10 && Integer.parseInt(day1)<=31)
		        				||"01".equals(day1)||"02".equals(day1)||"03".equals(day1)
				        		||"04".equals(day1)||"05".equals(day1)||"06".equals(day1)
				        		||"07".equals(day1)||"08".equals(day1)||"09".equals(day1)) || "".equals(day))) {
				try{
                    Scanner x = new Scanner(new File("car-database.txt"));
                    
                	while(x.hasNextLine())
                	{
                		String s = x.nextLine(); 
                        String[] sArray = s.split(",");
                       	if(sArray[10].contains(year+"-"+month+"-"+day)) {  		
                       			
                       			rev =re+ Integer.parseInt(sArray[8].trim());
                       			re=rev;
                       	}
                	}
                	
                	x.close();
                	if(re==0) {
                		JOptionPane.showMessageDialog(null,"No cars sold on this month/day","Error",JOptionPane.ERROR_MESSAGE);
                	}
                	else {
                		JOptionPane.showMessageDialog(null,"Revenue: "+re,"Success",JOptionPane.INFORMATION_MESSAGE);
                	}
                }
                catch(Exception e1) {
					JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);						
                }}
		        else {
		        	JOptionPane.showMessageDialog(null,"Date format invalid","Error",JOptionPane.ERROR_MESSAGE);
		        }
				
			}}
		});
		btnCalculate.setBounds(215, 86, 117, 29);
		contentPane.add(btnCalculate);
		
		JButton button = new JButton("?");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"The format must be with 4 digits for the year box and 2 digits for the day and month box \n"
						+ "If you want to calculate revenue for 1 month you complete the first 2 boxes and leave the day box empty","Help",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		button.setBounds(6, 6, 49, 29);
		contentPane.add(button);
	}
}
