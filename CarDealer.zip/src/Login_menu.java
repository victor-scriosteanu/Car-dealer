import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Base64;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Color;



public class Login_menu {

	private JFrame frame;
	private JTextField textUsername;
	private JPasswordField textPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_menu window = new Login_menu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login_menu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(153, 204, 255));
		frame.setBounds(100, 100, 310, 231);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		lblUsername.setBounds(37, 68, 117, 23);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		lblPassword.setBounds(37, 103, 117, 23);
		frame.getContentPane().add(lblPassword);
		
		textUsername = new JTextField();
		textUsername.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		textUsername.setBounds(133, 66, 130, 26);
		frame.getContentPane().add(textUsername);
		textUsername.setColumns(10);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		btnLogin.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent event) {
				String username = textUsername.getText();
				String password = textPassword.getText();
				Boolean found = false;
                try{

                    Scanner x = new Scanner(new File("cars-users.txt"));
                	while(x.hasNextLine())
                	{
                        String s = x.nextLine();  
                        String[] sArray = s.split(",");
                        
                        String originalInput = password;
                        String encodedString = Base64.getEncoder().encodeToString(originalInput.getBytes());
                        
                        
                       
                        if (sArray[0].trim().equals(username.trim()) && sArray[1].trim().equals(encodedString.trim()))
                        {
                            if(sArray[2].trim().equals("admin".trim())) 
                            {

        						found = true;
        						frame.dispose();
        						JOptionPane.showMessageDialog(null,"Welcome back, "+username+"!", "Success",JOptionPane.INFORMATION_MESSAGE);
        						Admin_menu admin = new Admin_menu();
        						admin.setVisible(true);
        						break;
                            }
                            if(sArray[2].trim().equals("staff".trim())) 
                            {
                            	found = true;
        						frame.dispose();
        						JOptionPane.showMessageDialog(null,"Welcome, "+username+"!", "Success",JOptionPane.INFORMATION_MESSAGE);
        						Staff_Admin_menu staff = new Staff_Admin_menu();
        						staff.setVisible(true);
        						break;
                            }
                            if(sArray[2].trim().equals("customer".trim())) 
                            {
                            	found = true;
        						frame.dispose();
        						JOptionPane.showMessageDialog(null,"Welcome, "+username+"!", "Success",JOptionPane.INFORMATION_MESSAGE);
        						Customer_Search customer = new Customer_Search();
        						customer.setVisible(true);
        						break;
                            }
                        }
                	}
                    x.close();
                    if (found==false)
                    {
      					JOptionPane.showMessageDialog(null,"Username or password incorrect","Login Error",JOptionPane.ERROR_MESSAGE);
      					textPassword.setText(null);
      					textUsername.setText(null);

                    }
                      
                }
                catch(Exception e) {
					JOptionPane.showMessageDialog(null,"Filepath not found","Login Error",JOptionPane.ERROR_MESSAGE);
					textPassword.setText(null);
					textUsername.setText(null);
					
                }	
			}

		});

		btnLogin.setBounds(143, 143, 111, 29);
		frame.getContentPane().add(btnLogin);
		
		textPassword = new JPasswordField();
		textPassword.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		textPassword.setBounds(133, 103, 130, 26);
		frame.getContentPane().add(textPassword);
		
		JLabel lblLoginSystem = new JLabel("Login System");
		lblLoginSystem.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblLoginSystem.setBounds(81, 6, 170, 37);
		frame.getContentPane().add(lblLoginSystem);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textUsername.setText(null);
				textPassword.setText(null);
			}
		});
		btnReset.setBounds(37, 143, 78, 29);
		frame.getContentPane().add(btnReset);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.DARK_GRAY);
		separator.setBounds(6, 184, 298, 12);
		frame.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.DARK_GRAY);
		separator_1.setBounds(6, 47, 298, 9);
		frame.getContentPane().add(separator_1);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
               System.exit(0);
				
			}
		});
		btnExit.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		btnExit.setBounds(229, 6, 75, 29);
		frame.getContentPane().add(btnExit);
		
		JButton button = new JButton("?");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Enter your username and password in the boxes alocated\n"
						+ "Once loged in you can log out only by restarting the program","Help",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		button.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		button.setBounds(6, 6, 40, 29);
		frame.getContentPane().add(button);

	}
}
