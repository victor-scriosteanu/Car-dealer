
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.File;

import java.util.Scanner;
import java.awt.event.ActionEvent;

public class Search extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtModel;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	private final ButtonGroup buttonGroup_3 = new ButtonGroup();
	private JTextField txtColour;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search frame = new Search();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Search() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1065, 572);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSearch = new JLabel("Search Menu");
		lblSearch.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblSearch.setBounds(473, 16, 187, 25);
		contentPane.add(lblSearch);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 180, 1028, 312);
		contentPane.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.DARK_GRAY);
		separator.setBounds(6, 45, 1053, 12);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.DARK_GRAY);
		separator_1.setBounds(6, 495, 1053, 12);
		contentPane.add(separator_1);
		
		JLabel lblNum = new JLabel("Model:");
		lblNum.setBounds(40, 74, 61, 16);
		contentPane.add(lblNum);
		
		txtModel = new JTextField();
		txtModel.setBounds(98, 69, 215, 26);
		contentPane.add(txtModel);
		txtModel.setColumns(10);
		
		JLabel lblTransmission = new JLabel("Transmission:");
		lblTransmission.setBounds(40, 111, 89, 16);
		contentPane.add(lblTransmission);
		
		JRadioButton rdbtnAutomatic = new JRadioButton("Automatic");
		rdbtnAutomatic.setSelected(true);
		buttonGroup.add(rdbtnAutomatic);
		rdbtnAutomatic.setBounds(137, 107, 97, 23);
		contentPane.add(rdbtnAutomatic);
		
		JRadioButton rdbtnManual = new JRadioButton("Manual");
		buttonGroup.add(rdbtnManual);
		rdbtnManual.setBounds(236, 107, 77, 23);
		contentPane.add(rdbtnManual);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnAutomatic.setActionCommand("automatic");
				rdbtnManual.setActionCommand("manual");
				String transmission = buttonGroup.getSelection().getActionCommand();
				String model = txtModel.getText();
				String colour = txtColour.getText();
		        System.out.println(transmission);
		        textArea.setText("");
				try{
                    Scanner x = new Scanner(new File("car-database.txt"));
                	while(x.hasNextLine())
                	{
                		
                        String s = x.nextLine();  
                        String[] sArray = s.split(",");
                        
                       	if((transmission.equals(sArray[7].trim()) && (" "+model).equals(sArray[1])) || (" "+colour).equals(sArray[4]) ) {
                       		
                       		textArea.append(sArray[0]+","+sArray[1]+","+sArray[2]+","+sArray[3]+","+sArray[4]+","+sArray[5]+","+sArray[6]+","+sArray[7]+","+sArray[8]+","+sArray[9]+","+sArray[10]);
                       		textArea.append("\n");
                        		
                       	}

                    	
  
                	}
                	x.close();
                }
                catch(Exception e1) {
					JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);						
                }
			}
		});
		btnSearch.setBounds(196, 139, 117, 29);
		contentPane.add(btnSearch);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setForeground(Color.DARK_GRAY);
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(336, 57, 12, 117);
		contentPane.add(separator_2);
		
		JLabel lblMinNumberOf = new JLabel("Min. number of seats:");
		lblMinNumberOf.setBounds(360, 74, 137, 16);
		contentPane.add(lblMinNumberOf);
		
		JRadioButton radioButton = new JRadioButton("2");
		radioButton.setSelected(true);
		buttonGroup_1.add(radioButton);
		radioButton.setBounds(496, 70, 40, 23);
		contentPane.add(radioButton);
		
		JRadioButton radioButton_1 = new JRadioButton("3");
		buttonGroup_1.add(radioButton_1);
		radioButton_1.setBounds(535, 70, 40, 23);
		contentPane.add(radioButton_1);
		
		JRadioButton radioButton_2 = new JRadioButton("4");
		buttonGroup_1.add(radioButton_2);
		radioButton_2.setBounds(572, 70, 40, 23);
		contentPane.add(radioButton_2);
		
		JRadioButton radioButton_3 = new JRadioButton("5");
		buttonGroup_1.add(radioButton_3);
		radioButton_3.setBounds(609, 70, 40, 23);
		contentPane.add(radioButton_3);
		
		JRadioButton radioButton_4 = new JRadioButton("6");
		buttonGroup_1.add(radioButton_4);
		radioButton_4.setBounds(646, 70, 40, 23);
		contentPane.add(radioButton_4);
		
		JRadioButton radioButton_5 = new JRadioButton("7");
		buttonGroup_1.add(radioButton_5);
		radioButton_5.setBounds(684, 70, 40, 23);
		contentPane.add(radioButton_5);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setForeground(Color.DARK_GRAY);
		separator_3.setOrientation(SwingConstants.VERTICAL);
		separator_3.setBounds(729, 57, 12, 117);
		contentPane.add(separator_3);
		
		JLabel lblMaxNumberOf = new JLabel("Max. number of seats:");
		lblMaxNumberOf.setBounds(360, 111, 140, 16);
		contentPane.add(lblMaxNumberOf);
		
		JRadioButton radioButton_6 = new JRadioButton("2");
		buttonGroup_2.add(radioButton_6);
		radioButton_6.setBounds(496, 107, 40, 23);
		contentPane.add(radioButton_6);
		
		JRadioButton radioButton_7 = new JRadioButton("3");
		radioButton_7.setSelected(true);
		buttonGroup_2.add(radioButton_7);
		radioButton_7.setBounds(535, 107, 40, 23);
		contentPane.add(radioButton_7);
		
		JRadioButton radioButton_8 = new JRadioButton("4");
		buttonGroup_2.add(radioButton_8);
		radioButton_8.setBounds(572, 107, 40, 23);
		contentPane.add(radioButton_8);
		
		JRadioButton radioButton_9 = new JRadioButton("5");
		buttonGroup_2.add(radioButton_9);
		radioButton_9.setBounds(609, 107, 40, 23);
		contentPane.add(radioButton_9);
		
		JRadioButton radioButton_10 = new JRadioButton("6");
		buttonGroup_2.add(radioButton_10);
		radioButton_10.setBounds(646, 107, 40, 23);
		contentPane.add(radioButton_10);
		
		JRadioButton radioButton_11 = new JRadioButton("7");
		buttonGroup_2.add(radioButton_11);
		radioButton_11.setBounds(684, 107, 40, 23);
		contentPane.add(radioButton_11);
		
		JButton btnSearch_1 = new JButton("Search");
		btnSearch_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				radioButton.setActionCommand("2");
				radioButton_1.setActionCommand("3");
				radioButton_2.setActionCommand("4");
				radioButton_3.setActionCommand("5");
				radioButton_4.setActionCommand("6");
				radioButton_5.setActionCommand("7");
				radioButton_6.setActionCommand("2");
				radioButton_7.setActionCommand("3");
				radioButton_8.setActionCommand("4");
				radioButton_9.setActionCommand("5");
				radioButton_10.setActionCommand("6");
				radioButton_11.setActionCommand("7");
				int min = Integer.parseInt(buttonGroup_1.getSelection().getActionCommand());
				int max = Integer.parseInt(buttonGroup_2.getSelection().getActionCommand());
		        textArea.setText("");
				try{
                    Scanner x = new Scanner(new File("car-database.txt"));
                	while(x.hasNextLine())
                	{
                		int seats=0;
                        String s = x.nextLine();  
                        String[] sArray = s.split(",");
                        if((" SUV").equals(sArray[2]) || (" Saloon").equals(sArray[2])) {
                        	seats=5;
                        }
                        if((" Coupe").equals(sArray[2])) {
                        	seats=2;
                        }
                        if((" Van").equals(sArray[2])) {
                        	seats=3;
                        }
                        if((" Hatchback").equals(sArray[2])) {
                        	seats=4;
                        }
                        if((" MPV").equals(sArray[2])) {
                        	seats=7;
                        }      
                       	if((max>=seats) && (min<=seats)) {
                       		
                       		textArea.append(sArray[0]+","+sArray[1]+","+sArray[2]+","+sArray[3]+","+sArray[4]+","+sArray[5]+","+sArray[6]+","+sArray[7]+","+sArray[8]+","+sArray[9]+","+sArray[10]);
                       		textArea.append("\n");                   		
                       	}
                	}
                	x.close();
                }
                catch(Exception e1) {
					JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);						
                }
				
			}
		});
		btnSearch_1.setBounds(474, 139, 117, 29);
		contentPane.add(btnSearch_1);
		
		JLabel lblSearchVansBy = new JLabel("Search vans by their specific size:");
		lblSearchVansBy.setBounds(790, 74, 212, 16);
		contentPane.add(lblSearchVansBy);
		
		JRadioButton rdbtnSmall = new JRadioButton("Small");
		rdbtnSmall.setSelected(true);
		buttonGroup_3.add(rdbtnSmall);
		rdbtnSmall.setBounds(790, 107, 66, 23);
		contentPane.add(rdbtnSmall);
		
		JRadioButton rdbtnLarge = new JRadioButton("Large");
		buttonGroup_3.add(rdbtnLarge);
		rdbtnLarge.setBounds(936, 107, 66, 23);
		contentPane.add(rdbtnLarge);
		
		JButton btnSearch_2 = new JButton("Search");
		btnSearch_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnSmall.setActionCommand("small");
				rdbtnLarge.setActionCommand("large");
				String size = buttonGroup_3.getSelection().getActionCommand();
		        textArea.setText("");
				try{
                    Scanner x = new Scanner(new File("car-database.txt"));
                	while(x.hasNextLine())
                	{
                		String s = x.nextLine();  
                        String[] sArray = s.split(",");
                       	if((" "+size).equals(sArray[3])) {  		
                       		textArea.append(sArray[0]+","+sArray[1]+","+sArray[2]+","+sArray[3]+","+sArray[4]+","+sArray[5]+","+sArray[6]+","+sArray[7]+","+sArray[8]+","+sArray[9]+","+sArray[10]);
                       		textArea.append("\n");		
                       	}
                	}
                	x.close();
                }
                catch(Exception e1) {
					JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);						
                }
			}
		});
		btnSearch_2.setBounds(842, 139, 117, 29);
		contentPane.add(btnSearch_2);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Admin_menu admin = new Admin_menu(); 
				admin.setVisible(true);
			}
		});
		btnBack.setBounds(982, 515, 77, 29);
		contentPane.add(btnBack);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(982, 18, 77, 29);
		contentPane.add(btnExit);
		
		JLabel lblColour = new JLabel("Colour:");
		lblColour.setBounds(40, 146, 61, 16);
		contentPane.add(lblColour);
		
		txtColour = new JTextField();
		txtColour.setBounds(98, 142, 89, 26);
		contentPane.add(txtColour);
		txtColour.setColumns(10);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("");
				txtModel.setText("");
				txtColour.setText("");
			}
		});
		btnReset.setBounds(16, 515, 89, 29);
		contentPane.add(btnReset);
		
		JButton button = new JButton("?");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"In the model box write the model of the car exactly as it is (respecting the capital letters) \n"
						+ "The program would recognize if you want to search model and colour at the same time and would display both car details\n"
						+ "For selecting an exact number of seats leave tick the boxes at the same number\n"
						+ "Searching for number of seats includes the number of box which you ticked as well(i.e. from 2 to 5 will dislplay all the cars with both 2 and 5 seats)\n"
						+ "The reset button resets only the text fields","Help",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		button.setBounds(6, 12, 40, 29);
		contentPane.add(button);
	}
}
