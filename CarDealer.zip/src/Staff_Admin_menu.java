
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class Staff_Admin_menu extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Staff_Admin_menu frame = new Staff_Admin_menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Staff_Admin_menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 614, 350);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAdminSystem = new JLabel("Admin System");
		lblAdminSystem.setFont(new Font("Lucida Grande", Font.PLAIN, 26));
		lblAdminSystem.setBounds(212, 19, 190, 43);
		contentPane.add(lblAdminSystem);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.DARK_GRAY);
		separator.setBounds(6, 74, 602, 12);
		contentPane.add(separator);
		
		JButton btnAddCars = new JButton("Add cars");
		btnAddCars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Staff_Add_cars create = new Staff_Add_cars();
				create.setVisible(true);
			}
		});
		btnAddCars.setBounds(131, 108, 157, 36);
		contentPane.add(btnAddCars);
		
		JButton btnSellCar = new JButton("Sell car");
		btnSellCar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Staff_Sell_car create = new Staff_Sell_car();
				create.setVisible(true);
				
			}
		});
		btnSellCar.setBounds(318, 108, 157, 36);
		contentPane.add(btnSellCar);
		
		JButton btnPrintCars = new JButton("Print cars");
		btnPrintCars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				
				String arrivaldate = "";
				
				if(true) {
					Calendar now = Calendar.getInstance();
					int year = now.get(Calendar.YEAR);
					String year1 = "";
					year1 = Integer.toString(year);
					int month = now.get(Calendar.MONTH);
					String month1 = "";
					month1 = Integer.toString(month);
					if(month1.length()==1) {
						month1 = "0"+month1;
					}
					int day = now.get(Calendar.DATE);
					String day1 = "";
					day1 = Integer.toString(day);
					if(day1.length()==1) {
						day1 = "0"+day1;
					}
					
					if("".equals(arrivaldate.trim())) {
						arrivaldate = year1+"-"+month1+"-"+day1;
					}
					int count = 0;
					int count1 = 0;
					
					try {
						Scanner xy = new Scanner(new File("car-database.txt"));
						String add = xy.useDelimiter("\\A").next();
						
						
						FileWriter writer = new FileWriter("temp1.txt",true);
						writer.write(add);
						writer.close();
						
						xy.close();
					}
					catch(Exception e1){
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);
						
					}
					try{
						
						FileWriter writer = new FileWriter("cars-output.txt",true);
	                    
	                    Scanner x = new Scanner(new File("temp1.txt"));
	                    writer.write("Sold cars:");
            			writer.write("\n");
            			writer.write("\n");
	                	while(x.hasNextLine())
	                	{
	                		count++;
	                        String s = x.nextLine();  
	                        String[] sArray = s.split(",");
	                        
	                       	
	                       	if(("".equals(sArray[9].trim())) && !("".equals(sArray[10].trim()))) {
	                       		writer.write(sArray[0]+","+sArray[1]+","+sArray[2]+","+sArray[3]+","+sArray[4]+","+sArray[5]+","+sArray[6]+","+sArray[7]+","+sArray[8]+", "+arrivaldate+","+sArray[10]);
	                       		writer.write("\n");
	                        		
	                       	}
	                       	else if(!("".equals(sArray[10].trim()))){
	                        		
	                       		writer.write(s);
	                			writer.write("\n");
	                				
	                				
	                        }
	                	}
	                	writer.close();
	                	x.close();
	                	PrintWriter writer1 = new PrintWriter("temp1.txt");
	                	writer1.print("");
						writer1.close();
	                      
	                }
	                catch(Exception e1) {
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);						
	                }
					try{
						
						FileWriter writer = new FileWriter("temp1.txt",true);
	                    
	                    Scanner x = new Scanner(new File("temp.txt"));
	                    
	                	while(x.hasNextLine())
	                	{
	                		count1++;
	                        String s = x.nextLine();
	        				writer.write(s);
	        				if(!(count1==count)){
	        					writer.write("\n");
	        				}
	                	}
	                	writer.close();
	                	x.close();
	                	PrintWriter writer1 = new PrintWriter("temp.txt");
	                	writer1.print("");
						writer1.close();
	                      
	                }
	                catch(Exception e1) {
						JOptionPane.showMessageDialog(null,"Filepath not found","Login Error",JOptionPane.ERROR_MESSAGE);
	                }
					int count2 = 0;
					int count3 = 0;
					
					try {
						Scanner xy = new Scanner(new File("car-database.txt"));
						String add = xy.useDelimiter("\\A").next();
						
						
						FileWriter writer = new FileWriter("temp1.txt",true);
						writer.write(add);
						writer.close();
						
						xy.close();
					}
					catch(Exception e1){
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);
						
					}
					try{
						
						FileWriter writer = new FileWriter("cars-output.txt",true);
	                    
	                    Scanner x = new Scanner(new File("temp1.txt"));
	                    writer.write("\n");
	                    writer.write("Unsold cars:");
            			writer.write("\n");
            			writer.write("\n");
	                	while(x.hasNextLine())
	                	{
	                		count2++;
	                        String s = x.nextLine();  
	                        String[] sArray = s.split(",");
	                        
	                       	
	                       	if(("".equals(sArray[9].trim())) && ("".equals(sArray[10].trim()))) {
	                       		writer.write(sArray[0]+","+sArray[1]+","+sArray[2]+","+sArray[3]+","+sArray[4]+","+sArray[5]+","+sArray[6]+","+sArray[7]+","+sArray[8]+", "+arrivaldate+","+sArray[10]);
	                       		writer.write("\n");
	                        		
	                       	}
	                       	else if(("".equals(sArray[10].trim()))){
	                        		
	                       		writer.write(s);
	                			writer.write("\n");	
	                        }
	                	}
	                	JOptionPane.showMessageDialog(null,"The list of cars was successfully printed to cars-output.txt file", "Success",JOptionPane.INFORMATION_MESSAGE);
	                	writer.write("\n");
	                	writer.close();
	                	x.close();
	                	PrintWriter writer1 = new PrintWriter("temp1.txt");
	                	writer1.print("");
						writer1.close();
	                }
	                catch(Exception e1) {
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);						
	                }
					try{
						FileWriter writer = new FileWriter("temp1.txt",true);
	                    Scanner x = new Scanner(new File("temp.txt"));
	                	while(x.hasNextLine())
	                	{
	                		count3++;
	                        String s = x.nextLine();
	        				writer.write(s);
	        				if(!(count3==count2)){
	        					writer.write("\n");
	        				}
	                	}
	                	writer.close();
	                	x.close();
	                	PrintWriter writer1 = new PrintWriter("temp.txt");
	                	writer1.print("");
						writer1.close();
	                      
	                }
	                catch(Exception e1) {
						JOptionPane.showMessageDialog(null,"Filepath not found","Login Error",JOptionPane.ERROR_MESSAGE);
	                }

				}
			}
		});
		btnPrintCars.setBounds(37, 198, 157, 36);
		contentPane.add(btnPrintCars);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Staff_Search create = new Staff_Search();
				create.setVisible(true);
			}
		});
		btnSearch.setBounds(227, 198, 157, 36);
		contentPane.add(btnSearch);
		
		JButton btnCalculateRevenue = new JButton("Calculate revenue");
		btnCalculateRevenue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Staff_Calculate_revenue create = new Staff_Calculate_revenue();
				create.setVisible(true);
			}
		});
		btnCalculateRevenue.setBounds(416, 198, 157, 36);
		contentPane.add(btnCalculateRevenue);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.DARK_GRAY);
		separator_1.setBounds(6, 258, 602, 12);
		contentPane.add(separator_1);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	               System.exit(0);
			}
		});
		btnExit.setBounds(533, 6, 75, 29);
		contentPane.add(btnExit);
		
		JButton button = new JButton("?");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"In order to log out you need to restart the program\n"
						+ "Button 'Print cars' will print directly all the cars from database into sold and unsold in the cars-output.txt file\n"
						+"Entering in each menu you could return to this menu pressing the back button","Help",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		button.setBounds(6, 6, 40, 29);
		contentPane.add(button);
		


	}

}
