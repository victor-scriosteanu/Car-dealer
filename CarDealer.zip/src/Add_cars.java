
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class Add_cars extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNumberplate;
	private JTextField txtModel;
	private JTextField txtSize;
	private JTextField textCartype;
	private JTextField txtColour;
	private JTextField txtMileage;
	private JTextField txtAccidenthistory;
	private JTextField txtTransmission;
	private JTextField txtPrice;
	private JTextField txtArrivaldate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_cars frame = new Add_cars();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_cars() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1026, 481);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddCars = new JLabel("Add Cars ");
		lblAddCars.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblAddCars.setBounds(465, 14, 95, 25);
		contentPane.add(lblAddCars);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.DARK_GRAY);
		separator.setBounds(6, 51, 1014, 12);
		contentPane.add(separator);
		
		JLabel lblNumberplate = new JLabel("Number plate:");
		lblNumberplate.setBounds(44, 91, 98, 16);
		contentPane.add(lblNumberplate);
		
		txtNumberplate = new JTextField();
		txtNumberplate.setForeground(Color.BLACK);
		txtNumberplate.setText("HN67VIC");
		txtNumberplate.setBounds(154, 86, 130, 26);
		contentPane.add(txtNumberplate);
		txtNumberplate.setColumns(10);
		
		JLabel lblCarType = new JLabel("Car type:");
		lblCarType.setBounds(44, 147, 61, 16);
		contentPane.add(lblCarType);
		
		txtModel = new JTextField();
		txtModel.setForeground(Color.BLACK);
		txtModel.setText("Skoda Octavia");
		txtModel.setBounds(154, 114, 130, 26);
		contentPane.add(txtModel);
		txtModel.setColumns(10);
		
		JLabel lblSize = new JLabel("Size (for vans):");
		lblSize.setBounds(44, 175, 98, 16);
		contentPane.add(lblSize);
		
		txtSize = new JTextField();
		txtSize.setBounds(154, 170, 130, 26);
		contentPane.add(txtSize);
		txtSize.setColumns(10);
		
		JLabel lblModel = new JLabel("Model:");
		lblModel.setBounds(44, 119, 61, 16);
		contentPane.add(lblModel);
		
		textCartype = new JTextField();
		textCartype.setText("Saloon");
		textCartype.setBounds(154, 142, 130, 26);
		contentPane.add(textCartype);
		textCartype.setColumns(10);
		
		JLabel lblColour = new JLabel("Colour:");
		lblColour.setBounds(44, 203, 61, 16);
		contentPane.add(lblColour);
		
		txtColour = new JTextField();
		txtColour.setText("gray");
		txtColour.setBounds(154, 198, 130, 26);
		contentPane.add(txtColour);
		txtColour.setColumns(10);
		
		JLabel lblMileage = new JLabel("Mileage:");
		lblMileage.setBounds(44, 231, 61, 16);
		contentPane.add(lblMileage);
		
		txtMileage = new JTextField();
		txtMileage.setText("80000");
		txtMileage.setBounds(154, 226, 130, 26);
		contentPane.add(txtMileage);
		txtMileage.setColumns(10);
		
		JLabel lblAccidentHistory = new JLabel("Accident history:");
		lblAccidentHistory.setBounds(44, 259, 107, 16);
		contentPane.add(lblAccidentHistory);
		
		txtAccidenthistory = new JTextField();
		txtAccidenthistory.setText("front damage");
		txtAccidenthistory.setBounds(154, 254, 130, 26);
		contentPane.add(txtAccidenthistory);
		txtAccidenthistory.setColumns(10);
		
		JLabel lblTransimisionType = new JLabel("Transmission:");
		lblTransimisionType.setBounds(44, 287, 107, 16);
		contentPane.add(lblTransimisionType);
		
		txtTransmission = new JTextField();
		txtTransmission.setText("manual");
		txtTransmission.setBounds(154, 282, 130, 26);
		contentPane.add(txtTransmission);
		txtTransmission.setColumns(10);
		
		JLabel lblPrice = new JLabel("Price:");
		lblPrice.setBounds(44, 315, 61, 16);
		contentPane.add(lblPrice);
		
		txtPrice = new JTextField();
		txtPrice.setText("10000");
		txtPrice.setBounds(154, 310, 130, 26);
		contentPane.add(txtPrice);
		txtPrice.setColumns(10);
		
		JLabel lblArrivalDate = new JLabel("Arrival date:");
		lblArrivalDate.setBounds(44, 343, 98, 16);
		contentPane.add(lblArrivalDate);
		

		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR);
		String year1 = "";
		year1 = Integer.toString(year);
		int month = now.get(Calendar.MONTH);
		String month1 = "";
		month1 = Integer.toString(month);
		if(month1.length()==1) {
			month1 = "0"+month1;
		}
		int date = now.get(Calendar.DATE);
		String date1 = "";
		date1 = Integer.toString(date);
		if(date1.length()==1) {
			date1 = "0"+date1;
		}
		txtArrivaldate = new JTextField();
		txtArrivaldate.setText(year1+'-'+month1+'-'+date1);
		txtArrivaldate.setBounds(154, 338, 130, 26);
		contentPane.add(txtArrivaldate);
		txtArrivaldate.setColumns(10);
		
		JButton btnAddCar = new JButton("Add car");
		btnAddCar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numberplate = txtNumberplate.getText();
				String model = txtModel.getText();
				String cartype = textCartype.getText();
				String size = txtSize.getText();
				String colour = txtColour.getText();
				String mileage = txtMileage.getText();
				String accidenthistory = txtAccidenthistory.getText();
				String transmission = txtTransmission.getText();
				String price = txtPrice.getText();
				String arrivaldate = txtArrivaldate.getText();
				Calendar now = Calendar.getInstance();
				int year = now.get(Calendar.YEAR);
				String year1 = "";
				year1 = Integer.toString(year);
				int month = now.get(Calendar.MONTH);
				String month1 = "";
				month1 = Integer.toString(month);
				if(month1.length()==1) {
					month1 = "0"+month1;
				}
				int day = now.get(Calendar.DATE);
				String day1 = "";
				day1 = Integer.toString(day);
				if(day1.length()==1) {
					day1 = "0"+day1;
				}
				
				if("".equals(arrivaldate.trim())) {
					arrivaldate = year1+"-"+month1+"-"+day1;
				}
				
				
				if(!"".equals(numberplate.trim()) && !"".equals(model.trim()) && !"".trim().equals(cartype.trim()) && !"".trim().equals(colour.trim()) && !"".trim().equals(mileage.trim()) && !"".trim().equals(accidenthistory.trim()) && !"".trim().equals(transmission.trim()) && !"".trim().equals(price.trim())) {
					if((("Van".equals(cartype.trim()) || "van".equals(cartype.trim())) && !"".equals(size.trim())) || ((!"Van".equals(cartype.trim()) && !"van".equals(cartype.trim())) && "".equals(size.trim()))) {
						
						try {
							FileWriter writer = new FileWriter("car-database.txt",true);
							writer.write("\n");
							writer.write(numberplate.trim()+", "+model+", "+cartype.trim()+", "+size.trim()+", "+colour+", "+mileage+", "+accidenthistory+", "+transmission+", "+price+", "+arrivaldate+", ");
							writer.close();
							JOptionPane.showMessageDialog(null,model+" was successfully added car database", "Success",JOptionPane.INFORMATION_MESSAGE);
		  					txtNumberplate.setText("HN89PIC");
		  					txtModel.setText("Dacia Logan");
		  					textCartype.setText("Saloon");
		  					txtSize.setText(null);
		  					txtColour.setText("yellow");
		  					txtMileage.setText("180000");
		  					txtAccidenthistory.setText("front damage");
		  					txtTransmission.setText("manual");
		  					txtPrice.setText("2000");
		  					txtArrivaldate.setText("2018-06-17");
						}
						catch(Exception e1){
							JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);
							System.exit(0);
						}

					}
					else {
						JOptionPane.showMessageDialog(null,"Select size the right size for van","Error",JOptionPane.ERROR_MESSAGE);
					}
				}
				else {
  					JOptionPane.showMessageDialog(null,"Please fill in all the necessary fields","Error",JOptionPane.ERROR_MESSAGE);
  					txtNumberplate.setText("HN67VIC");
  					txtModel.setText("Skoda Octavia");
  					textCartype.setText("Saloon");
  					txtSize.setText(null);
  					txtColour.setText("gray");
  					txtMileage.setText("80000");
  					txtAccidenthistory.setText("front damage");
  					txtTransmission.setText("manual");
  					txtPrice.setText("10000");
  					txtArrivaldate.setText("2018-06-30");
				}
			}
		});
		btnAddCar.setBounds(164, 370, 107, 29);
		contentPane.add(btnAddCar);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.DARK_GRAY);
		separator_1.setBounds(6, 411, 1014, 12);
		contentPane.add(separator_1);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Admin_menu admin = new Admin_menu();
				admin.setVisible(true);
			}
		});
		btnBack.setBounds(936, 424, 84, 29);
		contentPane.add(btnBack);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(936, 6, 84, 29);
		contentPane.add(btnExit);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setForeground(Color.DARK_GRAY);
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(294, 63, 23, 336);
		contentPane.add(separator_2);
		
		JLabel lblIfYouWant = new JLabel("If you want to add multiple cars please write the list ");
		lblIfYouWant.setBounds(329, 75, 331, 16);
		contentPane.add(lblIfYouWant);
		
		JLabel lblNewLabel = new JLabel("of cars in the box below in the following format:");
		lblNewLabel.setBounds(659, 75, 313, 16);
		contentPane.add(lblNewLabel);
		
		JTextArea txtadd = new JTextArea();
		txtadd.setFont(new Font("Lucida Grande", Font.PLAIN, 11));
		txtadd.setBounds(312, 147, 708, 156);
		contentPane.add(txtadd);
		
		JLabel lblNewLabel_1 = new JLabel("number plate, model, car type, size (live blank if the car");
		lblNewLabel_1.setBounds(328, 96, 351, 16);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblIsAVan = new JLabel("is a van), colour, mileage, accident history,");
		lblIsAVan.setBounds(682, 96, 362, 16);
		contentPane.add(lblIsAVan);
		
		JLabel lblTypePriceArrival = new JLabel("transmission, type, price, arrival date (with space after every comma).");
		lblTypePriceArrival.setBounds(329, 119, 437, 16);
		contentPane.add(lblTypePriceArrival);
		
		JButton btnAddCars = new JButton("Add cars");
		btnAddCars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String add = txtadd.getText();
				String arrivaldate = txtArrivaldate.getText();
				if("".equals(add.trim())) {
  					JOptionPane.showMessageDialog(null,"Please fill in with cars details","Error",JOptionPane.ERROR_MESSAGE);
  					txtadd.setText(null);
				}
				else {
					Calendar now = Calendar.getInstance();
					int year = now.get(Calendar.YEAR);
					String year1 = "";
					year1 = Integer.toString(year);
					int month = now.get(Calendar.MONTH);
					String month1 = "";
					month1 = Integer.toString(month);
					if(month1.length()==1) {
						month1 = "0"+month1;
					}
					int day = now.get(Calendar.DATE);
					String day1 = "";
					day1 = Integer.toString(day);
					if(day1.length()==1) {
						day1 = "0"+day1;
					}
					
					if("".equals(arrivaldate.trim())) {
						arrivaldate = year1+"-"+month1+"-"+day1;
					}
					int count = 0;
					int count1 = 0;
					
					try {
						FileWriter writer = new FileWriter("temp1.txt",true);
						writer.write(add);
						writer.close();
						txtadd.setText(null);
					}
					catch(Exception e1){
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);
						txtadd.setText(null);
					}
					try{
						
						FileWriter writer = new FileWriter("temp.txt",true);
	                    
	                    Scanner x = new Scanner(new File("temp1.txt"));
	                    
	                	while(x.hasNextLine())
	                	{
	                		count++;
	                        String s = x.nextLine();  
	                        String[] sArray = s.split(",");
	                        
	                       
	                       	
	                       	if(("".equals(sArray[9].trim()))) {
	                       		writer.write(sArray[0]+","+sArray[1]+","+sArray[2]+","+sArray[3]+","+sArray[4]+","+sArray[5]+","+sArray[6]+","+sArray[7]+","+sArray[8]+", "+arrivaldate+","+sArray[10]);
	                       		writer.write("\n");
	                        		
	                       	}
	                       	else {
	                        		
	                       		writer.write(s);
	                			writer.write("\n");
	                				
	                				
	                        }
	                    		
	  
	                	}

	                	writer.close();
	                	x.close();
	                	PrintWriter writer1 = new PrintWriter("temp1.txt");
	                	writer1.print("");
						writer1.close();
	                      
	                }
	                catch(Exception e1) {
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);

						
	                }
					try{
						
						FileWriter writer = new FileWriter("temp1.txt",true);
	                    
	                    Scanner x = new Scanner(new File("temp.txt"));
	                    
	                	while(x.hasNextLine())
	                	{
	                		count1++;
	                        String s = x.nextLine();  

	                        


	        				writer.write(s);
	        				if(!(count1==count)){
	        					writer.write("\n");
	        				}
	        					

	                        
	                	}
	                	writer.close();
	                	x.close();
	                	PrintWriter writer1 = new PrintWriter("temp.txt");
	                	writer1.print("");
						writer1.close();
	                      
	                }
	                catch(Exception e1) {
						JOptionPane.showMessageDialog(null,"Filepath not found","Login Error",JOptionPane.ERROR_MESSAGE);

						
	                }
					try {

						FileWriter writer = new FileWriter("car-database.txt",true);
						Scanner xy = new Scanner(new File("temp1.txt"));
						String text = xy.useDelimiter("\\A").next();
						
						writer.write("\n");
						writer.write(text);
						xy.close();
						writer.close();
						JOptionPane.showMessageDialog(null,"The list of cars was successfully added to the database", "Success",JOptionPane.INFORMATION_MESSAGE);
						txtadd.setText(null);
	                	PrintWriter writer1 = new PrintWriter("temp1.txt");
	                	writer1.print("");
						writer1.close();
					}
					catch(Exception e1){
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);
						txtadd.setText(null);
					}

					
				}

			}
		});
		btnAddCars.setBounds(608, 310, 117, 29);
		contentPane.add(btnAddCars);
		
		JLabel lblOr = new JLabel("Or import the list of cars from the cars-import.txt folder (with space after every comma).");
		lblOr.setBounds(329, 351, 570, 16);
		contentPane.add(lblOr);
		
		
		
		JButton btnImport = new JButton("Import");
		btnImport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String arrivaldate = txtArrivaldate.getText();
				
				if(true) {
					Calendar now = Calendar.getInstance();
					int year = now.get(Calendar.YEAR);
					String year1 = "";
					year1 = Integer.toString(year);
					int month = now.get(Calendar.MONTH);
					String month1 = "";
					month1 = Integer.toString(month);
					if(month1.length()==1) {
						month1 = "0"+month1;
					}
					int day = now.get(Calendar.DATE);
					String day1 = "";
					day1 = Integer.toString(day);
					if(day1.length()==1) {
						day1 = "0"+day1;
					}
					
					if("".equals(arrivaldate.trim())) {
						arrivaldate = year1+"-"+month1+"-"+day1;
					}
					int count = 0;
					int count1 = 0;
					
					try {
						Scanner xy = new Scanner(new File("cars-import.txt"));
						String add = xy.useDelimiter("\\A").next();
						
						
						FileWriter writer = new FileWriter("temp1.txt",true);
						writer.write(add);
						writer.close();
						txtadd.setText(null);
						xy.close();
					}
					catch(Exception e1){
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);
						txtadd.setText(null);
					}
					try{
						
						FileWriter writer = new FileWriter("temp.txt",true);
	                    
	                    Scanner x = new Scanner(new File("temp1.txt"));
	                    
	                	while(x.hasNextLine())
	                	{
	                		count++;
	                        String s = x.nextLine();  
	                        String[] sArray = s.split(",");
	                        
	                       
	                       	
	                       	if(("".equals(sArray[9].trim()))) {
	                       		writer.write(sArray[0]+","+sArray[1]+","+sArray[2]+","+sArray[3]+","+sArray[4]+","+sArray[5]+","+sArray[6]+","+sArray[7]+","+sArray[8]+", "+arrivaldate+","+sArray[10]);
	                       		writer.write("\n");
	                        		
	                       	}
	                       	else {
	                        		
	                       		writer.write(s);
	                			writer.write("\n");
	                				
	                				
	                        }
	                    		
	  
	                	}

	                	writer.close();
	                	x.close();
	                	PrintWriter writer1 = new PrintWriter("temp1.txt");
	                	writer1.print("");
						writer1.close();
	                      
	                }
	                catch(Exception e1) {
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);

						
	                }
					try{
						
						FileWriter writer = new FileWriter("temp1.txt",true);
	                    
	                    Scanner x = new Scanner(new File("temp.txt"));
	                    
	                	while(x.hasNextLine())
	                	{
	                		count1++;
	                        String s = x.nextLine();  
	        				writer.write(s);
	        				if(!(count1==count)){
	        					writer.write("\n"); 
	        				}
	                	}
	                	writer.close();
	                	x.close();
	                	PrintWriter writer1 = new PrintWriter("temp.txt");
	                	writer1.print("");
						writer1.close();
	                      
	                }
	                catch(Exception e1) {
						JOptionPane.showMessageDialog(null,"Filepath not found","Login Error",JOptionPane.ERROR_MESSAGE);

						
	                }
					try {

						FileWriter writer = new FileWriter("car-database.txt",true);
						Scanner xyz = new Scanner(new File("temp1.txt"));
						String text = xyz.useDelimiter("\\A").next();
						
						writer.write("\n");
						writer.write(text);
						xyz.close();
						writer.close();
						JOptionPane.showMessageDialog(null,"The list of cars was successfully added to the database", "Success",JOptionPane.INFORMATION_MESSAGE);
						txtadd.setText(null);
	                	PrintWriter writer1 = new PrintWriter("temp1.txt");
	                	writer1.print("");
						writer1.close();
						PrintWriter writer2 = new PrintWriter("cars-import.txt");
	                	writer2.print("");
						writer2.close();
					}
					catch(Exception e1){
						JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);
						txtadd.setText(null);
					}

					
				}
			}
		});
		btnImport.setBounds(608, 379, 117, 29);
		contentPane.add(btnImport);
		
		JButton button = new JButton("?");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"The date format is important to be YYYY-MM-DD(4,2 and 2 digits)\n"
						+ "For adding cars you can either type or copy in the text box the list of cars\n"
						+ "It's very important to leave a space after every comma\n"
						+ "It's possible also to enter the list of cars in the file cars-import.txt", "Help",JOptionPane.INFORMATION_MESSAGE);
				
			}
		});
		button.setBounds(6, 10, 40, 29);
		contentPane.add(button);
	}
}
