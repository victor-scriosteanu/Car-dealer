
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;

import java.io.File;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class Sell_car extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textcar;
	private JTextField txtDate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sell_car frame = new Sell_car();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sell_car() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSellACar = new JLabel("Sell a car");
		lblSellACar.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblSellACar.setBounds(171, 14, 86, 25);
		contentPane.add(lblSellACar);
		
		textcar = new JTextField();
		textcar.setText("LLNNLLL");
		textcar.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		textcar.setBounds(223, 91, 130, 26);
		contentPane.add(textcar);
		textcar.setColumns(10);
		
		JLabel lblNumberPlate = new JLabel("Number plate:");
		lblNumberPlate.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		lblNumberPlate.setBounds(100, 96, 111, 16);
		contentPane.add(lblNumberPlate);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.DARK_GRAY);
		separator.setBounds(6, 51, 438, 12);
		contentPane.add(separator);
		
		JLabel lblSellingDate = new JLabel("Selling date:");
		lblSellingDate.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		lblSellingDate.setBounds(100, 143, 87, 19);
		contentPane.add(lblSellingDate);
		
		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR);
		String year1 = "";
		year1 = Integer.toString(year);
		int month = now.get(Calendar.MONTH);
		String month1 = "";
		month1 = Integer.toString(month);
		if(month1.length()==1) {
			month1 = "0"+month1;
		}
		int date = now.get(Calendar.DATE);
		String date1 = "";
		date1 = Integer.toString(date);
		if(date1.length()==1) {
			date1 = "0"+date1;
		}
		txtDate = new JTextField();
		txtDate.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		txtDate.setText(year1+"-"+month1+"-"+date1);
		txtDate.setBounds(223, 139, 130, 26);
		contentPane.add(txtDate);
		txtDate.setColumns(10);
		
		

		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String plate = textcar.getText();
				String date = txtDate.getText();
				
				Calendar now = Calendar.getInstance();
				int year = now.get(Calendar.YEAR);
				String year1 = "";
				year1 = Integer.toString(year);
				int month = now.get(Calendar.MONTH);
				String month1 = "";
				month1 = Integer.toString(month);
				if(month1.length()==1) {
					month1 = "0"+month1;
				}
				int day = now.get(Calendar.DATE);
				String day1 = "";
				day1 = Integer.toString(day);
				if(day1.length()==1) {
					day1 = "0"+day1;
				}
				
				if("".equals(date.trim())) {
					date = year1+"-"+month1+"-"+day1;
				}
				int count = 0;
				int count1 = 0;
				Boolean found = false;
				try{
					
					FileWriter writer = new FileWriter("temp.txt",true);
                    
                    Scanner x = new Scanner(new File("car-database.txt"));
                    
                	while(x.hasNextLine())
                	{
                		count++;
                        String s = x.nextLine();  
                        String[] sArray = s.split(",");
                        
                        if (sArray[0].trim().equals(plate.trim()))
                        {
                        	found = true;
                        	if(("".equals(sArray[10].trim()))) {
                        		writer.write(sArray[0]+","+sArray[1]+","+sArray[2]+","+sArray[3]+","+sArray[4]+","+sArray[5]+","+sArray[6]+","+sArray[7]+","+sArray[8]+","+sArray[9]+", "+date);
                        		writer.write("\n");
                        		JOptionPane.showMessageDialog(null,"Car sold successfully", "Success",JOptionPane.INFORMATION_MESSAGE);
                        		textcar.setText("LLNNLLL");
                				txtDate.setText("2019-04-12");
                        	}
                        	else {
                        		
                        		writer.write(s);
                				writer.write("\n");
                				JOptionPane.showMessageDialog(null,"Car already sold","Error",JOptionPane.ERROR_MESSAGE);
                				
                        	}
                    		
        					
                        }
                        else {

                    		writer.write(s);
            				writer.write("\n");
                        	
                        }
                	}
                	if(!found) {
                		JOptionPane.showMessageDialog(null,"Car not found","Error",JOptionPane.ERROR_MESSAGE);
                	}
                	writer.close();
                	x.close();
                	PrintWriter writer1 = new PrintWriter("car-database.txt");
                	writer1.print("");
					writer1.close();
                      
                }
                catch(Exception e1) {
					JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);

					
                }
				try{
					
					FileWriter writer = new FileWriter("car-database.txt",true);
                    
                    Scanner x = new Scanner(new File("temp.txt"));
                    
                	while(x.hasNextLine())
                	{
                		count1++;
                        String s = x.nextLine();  

                        


        				writer.write(s);
        				if(!(count1==count)){
        					writer.write("\n");
        				}
        					

                        
                	}
                	writer.close();
                	x.close();
                	PrintWriter writer1 = new PrintWriter("temp.txt");
                	writer1.print("");
					writer1.close();
                      
                }
                catch(Exception e1) {
					JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);

					
                }
			}
		});
		btnSubmit.setBounds(233, 186, 117, 29);
		contentPane.add(btnSubmit);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.DARK_GRAY);
		separator_1.setBounds(6, 233, 438, 12);
		contentPane.add(separator_1);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				System.exit(0);
			}
		});
		btnExit.setBounds(363, 16, 81, 29);
		contentPane.add(btnExit);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Admin_menu admin = new Admin_menu();
				admin.setVisible(true);
			}
		});
		btnBack.setBounds(369, 243, 81, 29);
		contentPane.add(btnBack);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textcar.setText("LLNNLLL");
				txtDate.setText("2019-04-12");
			}
		});
		btnReset.setBounds(110, 186, 87, 29);
		contentPane.add(btnReset);
		
		JButton btnNewButton = new JButton("?");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"The date is important to be in the exact format as showed in the box(YYYY-MM-DD)\n"
						+ "The plate number should be all writen with capital letters otherwise the car won't be found\n"
						+ "If the date box is empty the program would alocate today's date as the selling date","Help",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton.setBounds(6, 16, 40, 29);
		contentPane.add(btnNewButton);
	}

}
