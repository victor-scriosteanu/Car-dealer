import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.util.Base64;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;

public class Create_credentials extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textusername;
	private JPasswordField textpassword;
	private JPasswordField textretype_password;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Create_credentials frame = new Create_credentials();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Create_credentials() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCredentialsMenu = new JLabel("Credentials Menu");
		lblCredentialsMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblCredentialsMenu.setBackground(new Color(255, 255, 255));
		lblCredentialsMenu.setBounds(133, 6, 178, 39);
		contentPane.add(lblCredentialsMenu);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setBounds(36, 72, 84, 22);
		contentPane.add(lblUsername);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.DARK_GRAY);
		separator.setBounds(6, 48, 438, 12);
		contentPane.add(separator);
		
		textusername = new JTextField();
		textusername.setBounds(179, 70, 161, 26);
		contentPane.add(textusername);
		textusername.setColumns(10);
		
		textpassword = new JPasswordField();
		textpassword.setBounds(179, 105, 161, 26);
		contentPane.add(textpassword);
		textpassword.setColumns(10);
		
		textretype_password = new JPasswordField();
		textretype_password.setBounds(179, 143, 161, 26);
		contentPane.add(textretype_password);
		textretype_password.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(36, 106, 85, 25);
		contentPane.add(lblPassword);
		
		JLabel lblRetypePassword = new JLabel("Confirm password:");
		lblRetypePassword.setBounds(36, 143, 128, 26);
		contentPane.add(lblRetypePassword);
		
		JButton btnCreateAccount = new JButton("Create account");
		btnCreateAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = textusername.getText();
				String password = textpassword.getText();
				String confirmpassword = textretype_password.getText();
				String role = buttonGroup.getSelection().getActionCommand();
				if(!"".trim().equals(username.trim()) && !"".trim().equals(password.trim()) && !"".trim().equals(confirmpassword.trim()) ) {
					if(password.trim().equals(confirmpassword.trim())) {
						System.out.println(role);
						try {
							FileWriter writer = new FileWriter("cars-users.txt",true);
	                        String originalInput = password.trim();
	                        String encodedString = Base64.getEncoder().encodeToString(originalInput.getBytes());
	                        System.out.println(encodedString);
							writer.write("\n");
							writer.write(username.trim()+","+encodedString+","+role);
							writer.close();
							if(role.equals("staff"))
							{
								JOptionPane.showMessageDialog(null,"Staff account added succesfuly", "Success",JOptionPane.INFORMATION_MESSAGE);
							}
							else
							{
								JOptionPane.showMessageDialog(null,"Customer account added succesfuly", "Success",JOptionPane.INFORMATION_MESSAGE);
							}
	      					textpassword.setText(null);
	      					textusername.setText(null);
	      					textretype_password.setText(null);
						}
						catch(Exception e1){
							JOptionPane.showMessageDialog(null,"Filepath not found","Error",JOptionPane.ERROR_MESSAGE);
						}
					}
					else {
      					JOptionPane.showMessageDialog(null,"Please enter the same password","Error",JOptionPane.ERROR_MESSAGE);
      					textpassword.setText(null);
      					textusername.setText(null);
      					textretype_password.setText(null);
					}
				}
				else {
  					JOptionPane.showMessageDialog(null,"Please fill in all the fields","Error",JOptionPane.ERROR_MESSAGE);
  					textpassword.setText(null);
  					textusername.setText(null);
  					textretype_password.setText(null);
				}	
			}
		});
		btnCreateAccount.setBounds(176, 202, 139, 29);
		contentPane.add(btnCreateAccount);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Admin_menu admin = new Admin_menu();
				admin.setVisible(true);
			}
			
		});
		btnBack.setBounds(376, 243, 68, 29);
		contentPane.add(btnBack);
		
		JRadioButton rdbtnStaff = new JRadioButton("Staff        ");
		rdbtnStaff.setSelected(true);
		rdbtnStaff.setActionCommand("staff");
		buttonGroup.add(rdbtnStaff);
		rdbtnStaff.setBounds(36, 179, 93, 23);
		contentPane.add(rdbtnStaff);
		
		JRadioButton rdbtnCustomer = new JRadioButton("Customer");
		rdbtnCustomer.setActionCommand("customer");
		buttonGroup.add(rdbtnCustomer);
		rdbtnCustomer.setBounds(36, 203, 93, 23);
		contentPane.add(rdbtnCustomer);

		
		JButton btnResetForm = new JButton("Reset form");
		btnResetForm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textusername.setText(null);
				textpassword.setText(null);
				textretype_password.setText(null);
				rdbtnStaff.setSelected(false);
				rdbtnCustomer.setSelected(false);
			}
		});
		btnResetForm.setBounds(327, 202, 117, 29);
		contentPane.add(btnResetForm);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	               System.exit(0);
			}
		});
		btnExit.setBounds(369, 15, 75, 29);
		contentPane.add(btnExit);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.DARK_GRAY);
		separator_1.setBounds(6, 231, 438, 12);
		contentPane.add(separator_1);
		
		JButton button = new JButton("?");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"The password must be exactly the same in both boxes\n"
						+ "Any username and password combination would work for a new account except one that already is in database(in this case the first account would remain valid)\n","Help",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		button.setBounds(4, 15, 40, 29);
		contentPane.add(button);
	}
}
